<?php
$mess = array(
    "1" => "Invitation",
    "1p" => "Invitations",
    "2" => "Shared File",
    "2p" => "Shared Files",
    "3" => "Invalid Share",
    "3p" => "Invalid Shares",
    "4" => "pending",
    "5" => "error",
    "6" => "Files shared with me",
    "7" => "These are the standalone files that people have shared with you. Folders are accessible directly via the left panel.",
    "8" => "Quick Filtering",
    "9" => "By file name",
    "10" => "By Type",
    "11" => "Clear",
    "12" => "Shared Files",
    "13" => "Files shared with me by other users",
    "14" => "Copy to a workspace",
    "15" => "Copy file to another of your workspaces",
    "16" => "Total",
    "17" => "New"
);
