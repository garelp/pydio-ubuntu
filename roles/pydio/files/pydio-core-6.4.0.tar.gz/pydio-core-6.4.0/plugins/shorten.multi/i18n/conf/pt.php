<?php
/*
* Multi shortener plugin for ajaXplorer by FrenandoAloso
*         based in bit.ly plugin
*/
$mess=array(
"multi URL Shortener" => "Redutor de Multi URLs",
"Shorten Download URLs before sending them back to the user." => "Reduzir URLs antes de os devolver ao utilizador.",
"User ID" => "ID de Utilizador",
"adF.ly account user ID. The numbers after -= ?id= =- in of your referral program's URL" => "ID de conta adF.ly ID.\nOs números após -= ?id= =- para usar o seu programa de Referral URLs",
"API Key" => "Chave API",
"adF.ly account API Key" => "Chave API da conta adF.ly",
"Type of ADS" => "Tipo de Publicidade",
"Type of AD you like to show. Select Fullscreen AD or Top banner AD" => "Tipo de Publicidade que gostaria de mostrar.\n Seleccione publicidade do tipo Ecrã Cheio ou Banner Superior",
"Short domain" => "Domino Curto",
"adF.ly or q.gs domains, select wich you like" => "Seleccione um domínio adF.ly ou q.gs, que goste",
"FullScreen" => "Ecrã Cheio",
"Banner" => "Banner",
"Bit.ly URL Shortener" => "Redutor de URLs Bit.lyr",
"User Name" => "Nome de Utilizador",
"Bit.ly account user name" => "Nome de Conta de Utilizador Bit.ly",
"Bit.ly account API Key" => "Chave API da conta Bit.ly",
"Shorten Download Links before sending them back to the user." => "Shorten Download Links before sending them back to the user.",
"Shorten Download Links before sending them back to the user. Requires a Bit.ly account." => "Shorten Download Links before sending them back to the user. Requires a Bit.ly account.",
"Yourls domain" => "Yourls domain",
"Use IDN" => "Use IDN",
"Shorten type" => "Shorten type",
);