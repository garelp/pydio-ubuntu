<?php
/*
* Multi shortener plugin for ajaXplorer by FrenandoAloso
*         based in bit.ly plugin
*/
$mess=array(
"multi URL Shortener" => "Abbreviare URL Multi",
"Shorten Download Links before sending them back to the user." => "Abbrevia i link di download prima di mostrarli all'utente.",
"User ID" => "ID Utente",
"adF.ly account user ID. The numbers after -= ?id= =- in of your referral program's URL" => "ID dell'utente di adF.ly.\nI numeri dopo -= ?id= =- nell'URL dell'applicativo di riferimento",
"API Key" => "Chiave API",
"adF.ly account API Key" => "Chiave API dell'account adF.ly",
"Type of ADS" => "Tipo di ADS",
"Type of AD you like to show. Select Fullscreen AD or Top banner AD" => "Tipo di AD che si desidera mostrare.\n Selezionare AD 'Schermo intero' o 'Tob banner'",
"Short domain" => "Dominio corto",
"adF.ly or q.gs domains, select wich you like" => "Domini adF.ly o q.gs. Indicare una preferenza.",
"FullScreen" => "SchermoIntero",
"Banner" => "Banner",
"Bit.ly URL Shortener" => "Abbreviatore URL Bit.ly",
"User Name" => "Nome Utente",
"Bit.ly account user name" => "Nome utente dell'account su Bit.ly",
"Bit.ly account API Key" => "Chiave API dell'account Bit.ly",
"Yourls domain" => "Dominio Yourls",
"Use IDN" => "Usa IDN",
"Shorten type" => "Tipo abbreviazione",
);
