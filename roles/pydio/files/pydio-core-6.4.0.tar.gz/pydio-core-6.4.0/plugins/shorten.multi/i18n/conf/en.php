<?php
/*
* Multi shortener plugin for ajaXplorer by FrenandoAloso
*         based in bit.ly plugin
*/
$mess=array(
"multi URL Shortener" => "Multi URL Shortener",
"Shorten Download Links before sending them back to the user." => "Shorten Download Links before sending them back to the user.",
"User ID" => "User ID",
"adF.ly account user ID. The numbers after -= ?id= =- in of your referral program's URL" => "adF.ly account user ID.\nThe numbers after -= ?id= =- in of your referral program's URL",
"API Key" => "API Key",
"adF.ly account API Key" => "adF.ly account API Key",
"Type of ADS" => "Type of ADS",
"Type of AD you like to show. Select Fullscreen AD or Top banner AD" => "Type of AD you like to show.\n Select Fullscreen AD or Top banner AD",
"Short domain" => "Short domain",
"adF.ly or q.gs domains, select wich you like" => "adF.ly or q.gs domains, select wich you like",
"FullScreen" => "FullScreen",
"Banner" => "Banner",
"Bit.ly URL Shortener" => "Bit.ly URL Shortener",
"User Name" => "User Name",
"Bit.ly account user name" => "Bit.ly account user name",
"Bit.ly account API Key" => "Bit.ly account API Key",
"Yourls domain" => "Yourls domain",
"Use IDN" => "Use IDN",
"Shorten type" => "Shorten type",
);