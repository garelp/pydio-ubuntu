<?php
/*
* Multi shortener plugin for ajaXplorer by FrenandoAloso
*         based in bit.ly plugin
*/
$mess=array(
"multi URL Shortener" => "Multi raccourcisseurs d'URL",
"Shorten Download Links before sending them back to the user." => "Raccourcir les liens de téléchargement avant de les renvoyer à l'utilisateur.",
"User ID" => "ID Utilisateur",
"adF.ly account user ID. The numbers after -= ?id= =- in of your referral program's URL" => "ID utilisateur sur adF.ly.\nLes nombres après -= ?id= =- dans l'URL de votre programme de référence",
"API Key" => "Clef d'API",
"adF.ly account API Key" => "Clef d'API du compte adF.ly",
"Type of ADS" => "Type de pub.",
"Type of AD you like to show. Select Fullscreen AD or Top banner AD" => "Type de publicité que vous souhaitez afficher.\n Choisissez 'Plein écran' ou 'Bannière en haut de page'",
"Short domain" => "Domaine raccourci",
"adF.ly or q.gs domains, select wich you like" => "Domaine adF.ly ou q.gs, choisissez celui que vous voulez",
"FullScreen" => "Plein écran",
"Banner" => "Bannière",
"Bit.ly URL Shortener" => "Raccourcisseur d'URL Bit.ly",
"User Name" => "Nom d'utilisateur",
"Bit.ly account user name" => "Nom d'utilisateur Bit.ly",
"Bit.ly account API Key" => "Clef d'API Bit.ly",
"Yourls domain" => "Domaine Yourls",
"Use IDN" => "Utiliser IDN",
"Shorten type" => "Type de raccourcissement",
);