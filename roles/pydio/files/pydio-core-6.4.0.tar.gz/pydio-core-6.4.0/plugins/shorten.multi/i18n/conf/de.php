<?php
/*
* Multi shortener plugin for ajaXplorer by FrenandoAloso
*         based in bit.ly plugin
*/
$mess=array(
"multi URL Shortener" => "Verschiedene URL-Kürzungsdienste",
"Shorten Download Links before sending them back to the user." => "Links zum Herunterladen von Dateien vor dem Versand an Benutzer kürzen.",
"User ID" => "Benutzer ID",
"adF.ly account user ID. The numbers after -= ?id= =- in of your referral program's URL" => "adF.ly Benutzer ID.\nDie Zahl nach -= ?id= =- in der URL",
"API Key" => "API Key",
"adF.ly account API Key" => "adF.ly API Key",
"Type of ADS" => "Art der Werbung",
"Type of AD you like to show. Select Fullscreen AD or Top banner AD" => "Art der Werbung, die angezeigt werden soll.\n Wähle Vollbild oder Banner am oberen Bildschirmrand",
"Short domain" => "Kurze Domain",
"adF.ly or q.gs domains, select wich you like" => "Wähle entweder adF.ly oder q.gs Domain.",
"FullScreen" => "Vollbild",
"Banner" => "Banner",
"Bit.ly URL Shortener" => "Bit.ly URL-Kürzungsdienst",
"User Name" => "Benutzername",
"Bit.ly account user name" => "Benutzername bei Bit.ly",
"Bit.ly account API Key" => "Bit.ly API Key",
"Yourls domain" => "Eigene Domain",
"Use IDN" => "Internationalisierten Domainnamen verwenden (IDN)",
"Shorten type" => "Anbieter",
);
