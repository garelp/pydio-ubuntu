<?php
$mess = array(
"name" => "Visualizzatore Email",
"title" => "Visualizzatore Email",
"1" => "Da",
"2" => "A",
"3" => "Oggetto",
"4"	=> "Data",
"5" => "Allegati",
"6" => "Download EML",
"7" => "Allegato %s è stato correttamente copiato in %s",
"8" => "Impossibile aprire il file!",
"9" => "Nessun allegato trovato!",
"10" => "Download ",
"11" => "Copia allegato sul server",
"12" => "Cc",
);
