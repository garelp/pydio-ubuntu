<?php
//  Estonian translation by Ardi Jürgens <ardi (at) zone.ee>
//  + updates/fixes by Kain Väljaots <kain (at) zone.ee>
//	Last update: 27.05.2013

$mess = array(
"name" => "E-posti luger",
"title" => "E-Posti luger",
"1" => "Kellelt",
"2" => "Kellele",
"3" => "Pealkiri",
"4"	=> "Kuupäev",
"5" => "Manus",
"6" => "Laadi EML fail alla",
"7" => "Manus %s kopeeriti edukalt asukohta %s",
"8" => "Sihtfaili ei olnud võimalik avada!",
"9" => "Manust ei leitud!",
"10" => "Laadi alla ",
"11" => "Kopeeri manus serveris",
"12" => "Koopia",
);
