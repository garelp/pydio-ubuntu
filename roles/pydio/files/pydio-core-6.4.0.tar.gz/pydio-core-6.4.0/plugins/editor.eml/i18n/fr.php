<?php
$mess = array(
"name" => "Editeur courriel",
"title" => "Editeur courriel",
"1" => "De",
"2" => "A",
"3" => "Sujet",
"4"	=> "Date",
"5" => "Pièces jointes",
"6" => "Télécharger EML",
"7" => "La pièce-jointe %s a été copiée avec succès dans %s",
"8" => "Impossible d'ouvrir le fichier de destination !",
"9" => "Impossible de trouver la pièce-jointe",
"10" => "Télécharger ",
"11" => "Copier la pièce-jointe sur le serveur",
"12" => "Cc",
);
