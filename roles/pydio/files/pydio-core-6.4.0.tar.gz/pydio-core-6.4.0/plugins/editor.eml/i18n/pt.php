<?php
$mess = array(
"name" => "Visualizador de E-mail",
"title" => "Visualizador de E-mail",
"1" => "De",
"2" => "para",
"3" => "Assunto",
"4"	=> "Data",
"5" => "Anexos",
"6" => "Transferir EML",
"7" => "O Anexo %s foi copiado com sucesso para %s",
"8" => "Não foi possível abrir o ficheiro de destino!",
"9" => "Não foi possível encontrar o anexo!",
"10" => "Transferir ",
"11" => "Copiar anexo para o servidor",
"12" => "Cc",
);
