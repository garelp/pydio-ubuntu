<?php

$mess = array(
"1" => "Aufnahmeort",
"2" => "Karte",
"3" => "Metadaten (EXIF)",
);
