<?php

$mess = array(
"1" => "Geolocalizzazione",
"2" => "Località",
    "3" => "Meta Data (EXIF)",
);
