<?php

$mess = array(
"1" => "Exif геолокация",
"2" => "Расположение",
    "3" => "Meta Data (EXIF)",
);
