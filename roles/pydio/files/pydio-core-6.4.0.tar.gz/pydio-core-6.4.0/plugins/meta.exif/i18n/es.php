<?php

$mess = array(
"1" => "GeoUbicación",
"2" => "Ubicar",
    "3" => "Meta Data (EXIF)",
);
