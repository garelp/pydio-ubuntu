<?php

$mess = array(
"1" => "Geolocalização",
"2" => "Localizar",
    "3" => "Meta Data (EXIF)",
);
