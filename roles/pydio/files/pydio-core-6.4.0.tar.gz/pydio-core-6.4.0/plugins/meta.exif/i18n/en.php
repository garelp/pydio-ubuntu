<?php

$mess = array(
"1" => "GeoLocation",
"2" => "Locate",
"3" => "Meta Data (EXIF)",
);
