<br>
<br>
<br>
<br>
<div align="center" style="font-family:Arial, Helvetica, Sans-serif;font-size:25px;color:#AAA;font-weight:bold;">Error while opening Pixlr editor!</div>
