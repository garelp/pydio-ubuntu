<?php

$mess = array(
"1" => "Commenti Utente",
"2" => "Inserisci il tuo commento quì",
"3" => "Invia",
"4" => "Vai a %s",
);
