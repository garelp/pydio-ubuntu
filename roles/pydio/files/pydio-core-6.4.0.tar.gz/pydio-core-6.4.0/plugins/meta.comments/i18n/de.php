<?php

$mess = array(
"1" => "Kommentare",
"2" => "Kommentar hier eingeben",
"3" => "Speichern",
"4" => "Zu %s wechseln",
);
