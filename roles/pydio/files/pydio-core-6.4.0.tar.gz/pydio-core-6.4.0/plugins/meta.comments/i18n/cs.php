<?php

$mess = array(
"1" => "Komentáře uživatelů",
"2" => "Sem zadejte svůj komentář",
"3" => "Zveřejnit",
"4" => "Jit na %s",
);
