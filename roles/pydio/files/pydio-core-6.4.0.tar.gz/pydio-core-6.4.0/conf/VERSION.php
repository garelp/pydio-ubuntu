<?php
define("AJXP_VERSION", "6.4.0");
define("AJXP_VERSION_DATE", "2016-03-31");
define("AJXP_VERSION_REV", "7446b98");
define("AJXP_VERSION_DB", "62");
